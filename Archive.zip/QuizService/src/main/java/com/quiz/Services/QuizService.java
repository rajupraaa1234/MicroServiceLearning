package com.quiz.Services;

import com.quiz.Entity.Quiz;
import org.springframework.stereotype.Service;

import java.util.List;

public interface QuizService {
    Quiz addQuiz(Quiz quiz);
    List<Quiz> getQuizList();

    Quiz getQuiz(Long id);

}
