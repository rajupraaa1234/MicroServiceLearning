package com.question.Services;

import com.question.Entity.Question;
import com.question.Repository.QuestionRepository;
import lombok.Setter;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
public class QuestionImpl implements QuestionServices{

    @Autowired
    private QuestionRepository questionRepository;
    @Override
    public List<Question> getQuestionList() {
        return questionRepository.findAll();
    }

    @Override
    public Question createQuestion(Question question) {
        questionRepository.save(question);
        return question;
    }

    @Override
    public Question getQuestion(Long id) {
        return questionRepository.findById(id).orElseThrow(()->new RuntimeException("Question Not Found"));
    }

    @Override
    public List<Question> getQuestionByQuizId(Long quizId) {
        return questionRepository.findByQuizId(quizId);
    }
}
