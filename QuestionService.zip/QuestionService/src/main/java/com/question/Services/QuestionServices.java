package com.question.Services;

import com.question.Entity.Question;

import java.util.List;

public interface QuestionServices {
       List<Question> getQuestionList();

       Question createQuestion(Question question);

       Question getQuestion(Long id);

       List<Question> getQuestionByQuizId(Long quizId);
}
