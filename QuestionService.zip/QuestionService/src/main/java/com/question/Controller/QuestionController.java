package com.question.Controller;


import com.question.Entity.Question;
import com.question.Services.QuestionServices;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("/question")
public class QuestionController {

    @Autowired
    private QuestionServices questionServices;


    @GetMapping("/list")
    public List<Question> getQuizList(){
        return questionServices.getQuestionList();
    }

    @PutMapping("/create")
    public Question addQuiz(@RequestBody Question quiz){
        return questionServices.createQuestion(quiz);
    }

    @GetMapping("/{id}")
    public Question getQuiz(@PathVariable Long id){
        return questionServices.getQuestion(id);
    }

    @GetMapping("/quiz/list/{id}")
    public List<Question> getQuestionByQuizId(@PathVariable Long id){
        return questionServices.getQuestionByQuizId(id);
    }

}
