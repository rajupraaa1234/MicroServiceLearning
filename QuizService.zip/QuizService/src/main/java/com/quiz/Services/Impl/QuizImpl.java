package com.quiz.Services.Impl;

import com.quiz.Entity.Quiz;
import com.quiz.Repository.QuizRepository;
import com.quiz.Services.QuestionClient;
import com.quiz.Services.QuizService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;
import java.util.stream.Collectors;

@Service
public class QuizImpl implements QuizService {

    @Autowired
    QuizRepository quizRepository;

    @Autowired
    private QuestionClient questionClient;
    @Override
    public Quiz addQuiz(Quiz quiz) {
        quizRepository.save(quiz);
        return quiz;
    }

    @Override
    public List<Quiz> getQuizList() {
        List<Quiz> quizzes = quizRepository.findAll();
        List<Quiz> newQuizList = quizzes.stream().map(quiz -> {
            quiz.setQuestions(questionClient.getQuestionOfQuiz(quiz.getId()));
            return quiz;
        }).collect(Collectors.toList());
       return  newQuizList;
        //return quizzes;
    }

    @Override
    public Quiz getQuiz(Long id) {
       Quiz quiz =  quizRepository.findById(id).orElseThrow(()->new RuntimeException("Quiz Not Found"));
       quiz.setQuestions(questionClient.getQuestionOfQuiz(quiz.getId()));
       return quiz;
    }
}
